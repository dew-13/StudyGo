import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AddNewCourse extends StatefulWidget {
  const AddNewCourse({super.key});
  @override
  AddNewCourseState createState() => AddNewCourseState();
}

class AddNewCourseState extends State<AddNewCourse> {
  final TextEditingController _courseNameController = TextEditingController();
  final TextEditingController _teacherController = TextEditingController();
  final TextEditingController _dateTimeController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void _saveCourse() async {
    if (_courseNameController.text.isNotEmpty &&
        _teacherController.text.isNotEmpty &&
        _dateTimeController.text.isNotEmpty) {
      await _firestore.collection('courses').add({
        'courseName': _courseNameController.text,
        'teacher': _teacherController.text,
        'classDateTime': _dateTimeController.text,
        'registeredStudents': [],
      });
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add New Course')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _courseNameController,
              decoration: InputDecoration(labelText: 'Course Name'),
            ),
            TextField(
              controller: _teacherController,
              decoration: InputDecoration(labelText: 'Teacher Name'),
            ),
            TextField(
              controller: _dateTimeController,
              decoration: InputDecoration(labelText: 'Class Date & Time'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveCourse,
              child: Text('Save Course'),
            ),
          ],
        ),
      ),
    );
  }
}

class CourseView extends StatefulWidget {
  final String courseId;
  const CourseView({super.key, required this.courseId});

  @override
  CourseViewState createState() => CourseViewState();
}

class CourseViewState extends State<CourseView> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<String> registeredStudents = [];

  @override
  void initState() {
    super.initState();
    _fetchRegisteredStudents();
  }

  Future<void> _fetchRegisteredStudents() async {
    DocumentSnapshot courseSnapshot =
        await _firestore.collection('courses').doc(widget.courseId).get();
    setState(() {
      registeredStudents = List<String>.from(courseSnapshot['registeredStudents'] ?? []);
    });
  }

  void _addStudentToCourse(String studentId) async {
    if (!registeredStudents.contains(studentId)) {
      registeredStudents.add(studentId);
      await _firestore.collection('courses').doc(widget.courseId).update({
        'registeredStudents': registeredStudents,
      });
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Course Details')),
      body: FutureBuilder<DocumentSnapshot>(
        future: _firestore.collection('courses').doc(widget.courseId).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          var courseData = snapshot.data!.data() as Map<String, dynamic>;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Course: ${courseData['courseName']}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    Text('Teacher: ${courseData['teacher']}'),
                    Text('Class Date & Time: ${courseData['classDateTime']}'),
                    Text('Registered Students: ${registeredStudents.length}'),
                  ],
                ),
              ),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore.collection('students').snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
                    List<DocumentSnapshot> students = snapshot.data!.docs;
                    students.sort((a, b) {
                      bool aAdded = registeredStudents.contains(a.id);
                      bool bAdded = registeredStudents.contains(b.id);
                      return aAdded == bAdded ? 0 : (aAdded ? -1 : 1);
                    });
                    return ListView.builder(
                      itemCount: students.length,
                      itemBuilder: (context, index) {
                        var student = students[index].data() as Map<String, dynamic>;
                        bool isAdded = registeredStudents.contains(students[index].id);
                        return ListTile(
                          title: Text(student['name']),
                          subtitle: Text(student['contact']),
                          trailing: isAdded
                              ? Icon(Icons.check, color: Colors.green)
                              : ElevatedButton(
                                  onPressed: () => _addStudentToCourse(students[index].id),
                                  child: Text('Add to Course'),
                                ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
