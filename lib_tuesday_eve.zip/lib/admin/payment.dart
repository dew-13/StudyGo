import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:math';

class PaymentsPage extends StatefulWidget {
  const PaymentsPage({super.key});

  @override
  _PaymentsPageState createState() => _PaymentsPageState();
}

class _PaymentsPageState extends State<PaymentsPage> {
  String? selectedMonth;
  String? selectedCourse;
  List<String> months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  List<String> courses = [];
  List<Map<String, dynamic>> students = [];

  @override
  void initState() {
    super.initState();
    _fetchCourses();
  }

  Future<void> _fetchCourses() async {
    DatabaseReference database = FirebaseDatabase.instance.ref("courses");
    database.onValue.listen((event) {
      setState(() {
        courses = event.snapshot.children.map((e) => e.key.toString()).toList();
      });
    });
  }

  Future<void> _fetchStudents() async {
    if (selectedCourse == null) return;
    DatabaseReference database = FirebaseDatabase.instance.ref("students");
    database.onValue.listen((event) {
      setState(() {
        students = event.snapshot.children.map((e) {
          return {
            "id": e.key,
            "name": e.child("name").value.toString(),
            "subject": e.child("subject").value.toString(),
          };
        }).where((student) => student["subject"] == selectedCourse).toList();
      });
    });
  }

  void _markAsPaid(String studentId) {
    if (selectedMonth == null || selectedCourse == null) return;
    DatabaseReference database = FirebaseDatabase.instance.ref("payments");
    String paymentID = Random().nextInt(100000).toString();
    DateTime now = DateTime.now();
    String paymentDate = "${now.year}-${now.month}-${now.day}";
    
    database.child(paymentID).set({
      "paymentID": paymentID,
      "paymentDate": paymentDate,
      "courseName": selectedCourse,
      "feeMonth": selectedMonth,
    });

    DatabaseReference studentRef = FirebaseDatabase.instance.ref("students/$studentId");
    studentRef.update({"paid": true});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Manage Payments"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedMonth,
              hint: Text("Select Month"),
              items: months.map((month) {
                return DropdownMenuItem(value: month, child: Text(month));
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedMonth = value;
                });
              },
            ),
            SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: selectedCourse,
              hint: Text("Select Course"),
              items: courses.map((course) {
                return DropdownMenuItem(value: course, child: Text(course));
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedCourse = value;
                  _fetchStudents();
                });
              },
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: students.length,
                itemBuilder: (context, index) {
                  final student = students[index];
                  return Card(
                    child: ListTile(
                      title: Text(student["name"]),
                      subtitle: Text("Course: ${student["course"]}"),
                      trailing: student["paid"]
                          ? Icon(Icons.check_circle, color: Colors.green)
                          : ElevatedButton(
                              onPressed: () {
                                _markAsPaid(student["id"]);
                              },
                              child: Text("Pending"),
                            ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}