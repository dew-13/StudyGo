import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:study_go/logins/login_screen.dart';
import 'package:study_go/theme/theme.dart';
import 'package:study_go/logins/custom_scaffold.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert'; // for the utf8.encode method

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formSignupKey = GlobalKey<FormState>();
  bool agreePersonalData = true;
  final TextEditingController _contactController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  // Function to hash the password using SHA-256
  String _hashPassword(String password) {
    var bytes = utf8.encode(password); // Convert the password to bytes
    var digest = sha256.convert(bytes); // Hash the password using SHA-256
    return digest.toString(); // Return the hashed password as a string
  }

  // Function to validate if passwords match
  String? _validatePasswordMatch(String? value) {
    if (value != _newPasswordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }

  // Function to validate the telephone number and OTP in Firebase
  Future<String?> _validatePhoneNumberAndOTP(String contact, String otp) async {
    // Hash the OTP before comparing
    final hashedOTP = _hashPassword(otp);

    // Check students table
    DatabaseEvent studentSnapshot = await _database
        .child('students')
        .orderByChild('contact')
        .equalTo(contact)
        .once();

    if (studentSnapshot.snapshot.value != null) {
      Map<dynamic, dynamic> students =
          studentSnapshot.snapshot.value as Map<dynamic, dynamic>;

      // Iterate through students to find the correct one
      for (var studentKey in students.keys) {
        var studentData = students[studentKey];
        if (studentData['contact'] == contact) {
          String storedPassword =
              studentData['password']; // Get stored password

          if (storedPassword == hashedOTP) {
            return studentKey; // Return the student key for updating
          } else {
            return 'invalid_otp'; // OTP does not match
          }
        }
      }
    }
    return null; // Phone number not found
  }

// Function to validate the telephone number and OTP for teachers in Firebase
  Future<String?> _validateTeacherPhoneNumberAndOTP(
      String contact, String otp) async {
    final hashedOTP = _hashPassword(otp);

    // Check teachers table
    DatabaseEvent teacherSnapshot = await _database
        .child('teachers')
        .orderByChild('contact')
        .equalTo(contact)
        .once();

    if (teacherSnapshot.snapshot.value != null) {
      Map<dynamic, dynamic> teachers =
          teacherSnapshot.snapshot.value as Map<dynamic, dynamic>;

      // Iterate through teachers to find the correct one
      for (var teacherKey in teachers.keys) {
        var teacherData = teachers[teacherKey];
        if (teacherData['contact'] == contact) {
          String storedPassword = teacherData['password'];

          if (storedPassword == hashedOTP) {
            return teacherKey; // Return the teacher key for updating
          } else {
            return 'invalid_otp'; // OTP does not match
          }
        }
      }
    }
    return null; // Phone number not found
  }

  // Function to update the password in the relevant table
  Future<void> _updatePassword(
    String studentKey,
    String password,
  ) async {
    // Hash the new password before saving
    final hashedPassword = _hashPassword(password);

    await _database
        .child('students/$studentKey')
        .update({'password': hashedPassword});
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      child: Column(
        children: [
          const Expanded(flex: 1, child: SizedBox(height: 10)),
          Expanded(
            flex: 7,
            child: Container(
              padding: const EdgeInsets.fromLTRB(25.0, 50.0, 25.0, 20.0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: SingleChildScrollView(
                child: Form(
                  key: _formSignupKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Get Started',
                        style: TextStyle(
                          fontSize: 30.0,
                          fontWeight: FontWeight.w900,
                          color: lightColorScheme.primary,
                        ),
                      ),
                      const SizedBox(height: 40.0),

                      // Telephone Number
                      TextFormField(
                        controller: _contactController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your registered telephone number';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          label: const Text('Registered Telephone Number'),
                          hintText: 'Enter Telephone Number',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // OTP
                      TextFormField(
                        controller: _otpController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter One Time Password';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          label: const Text('OTP'),
                          hintText: 'Enter First Time Password',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // New Password
                      TextFormField(
                        controller: _newPasswordController,
                        obscureText: true,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Enter a new password';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          label: const Text('New Password'),
                          hintText: 'Enter New Password',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // Confirm Password
                      TextFormField(
                        controller: _confirmPasswordController,
                        obscureText: true,
                        validator: _validatePasswordMatch,
                        decoration: InputDecoration(
                          label: const Text('Confirm New Password'),
                          hintText: 'Confirm New Password',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // Agreement Checkbox
                      Row(
                        children: [
                          Checkbox(
                            value: agreePersonalData,
                            onChanged: (bool? value) {
                              setState(() {
                                agreePersonalData = value!;
                              });
                            },
                            activeColor: lightColorScheme.primary,
                          ),
                          const Text(
                            'I agree to the processing of Personal data',
                          ),
                        ],
                      ),
                      const SizedBox(height: 25.0),

                      // Sign Up Button
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (_formSignupKey.currentState!.validate() &&
                                agreePersonalData) {
                              String contact = _contactController.text.trim();
                              String otp = _otpController.text.trim();
                              String password = _newPasswordController.text;

                              String? studentKey =
                                  await _validatePhoneNumberAndOTP(
                                contact,
                                otp,
                              );

                              if (studentKey == 'invalid_otp') {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Invalid OTP. Please enter the correct OTP.',
                                    ),
                                  ),
                                );
                              } else if (studentKey != null) {
                                await _updatePassword(studentKey, password);

                                // Navigate to Login Screen
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const LogInScreen(),
                                  ),
                                );

                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Password updated successfully!',
                                    ),
                                  ),
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Phone number not found in records',
                                    ),
                                  ),
                                );
                              }
                            } else if (!agreePersonalData) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Please agree to the processing of personal data',
                                  ),
                                ),
                              );
                            }
                          },
                          child: const Text('Sign up'),
                        ),
                      ),
                      const SizedBox(height: 25.0),

                      // Already a User? Login
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('Already a User? '),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (e) => const LogInScreen(),
                                ),
                              );
                            },
                            child: Text(
                              'Log in',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: lightColorScheme.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}